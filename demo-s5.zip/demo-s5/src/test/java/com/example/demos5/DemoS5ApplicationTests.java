package com.example.demos5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoS5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
