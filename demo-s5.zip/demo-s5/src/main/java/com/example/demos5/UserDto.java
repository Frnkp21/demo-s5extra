package com.example.demos5;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class UserDto {
    private Integer id;
    private String email;
    private String fullname;

    public UserDto(Integer id, String email, String fullname) {
        this.id = id;
        this.email = email;
        this.fullname = fullname;
    }
    public UserDto(User user){
        id = user.getId();
        email = user.getEmail();
        fullname = user.getFullname();
    }
    public UserDto(){

    }
}
