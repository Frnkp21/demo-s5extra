package com.example.demos5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
public class UserService {
    @Autowired
    UserDAO userDAO;
    public List<User> readAllUsers(){
    return userDAO.findAll();
    }

    public User getUserById(Integer id) {
        Optional<User>
        optionalUser = userDAO.findById(id);
        return optionalUser.orElse(null);
    }

    public User addUser(User user) {
        return userDAO.save(user);
    }
    public void removeUser(Integer id) {
        userDAO.deleteById(id);
    }
    public UserDto updateUser(Integer id, User updatedUser) {
        Optional<User> optionalExistingUser = userDAO.findById(id);

        if (optionalExistingUser.isPresent()) {
            User existingUser = optionalExistingUser.get();

            existingUser.setFullname(updatedUser.getFullname());
            existingUser.setEmail(updatedUser.getEmail());

            userDAO.save(existingUser);

            return new UserDto(existingUser);
        } else {
            return null;
        }
    }
    public User userUpdate(Integer id, Map<String,Object> updates){
        Optional<User> optionalUser = userDAO.findById(id);
        if (optionalUser.isPresent()){
            User existe = optionalUser.get();
            if (updates.containsKey("fullName")){
                existe.setEmail((String) updates.get("fullName"));
            }if (updates.containsKey("password")){
                existe.setEmail((String) updates.get("password"));
            }if (updates.containsKey("email")){
                existe.setEmail((String) updates.get("email"));
            }
            return userDAO.save(existe);

        }return null;
    }
}
